import json

with open("test1.json", "r") as file:
    data = json.load(file)

print("JSON Parsed Successfully!")
print(data)